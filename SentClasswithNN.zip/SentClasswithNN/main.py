from data_loader import load_imdb_data
from preprocessing import TextPreprocessor
from tokenizer_utils import TextTokenizer
from model_utils import build_model
import numpy as np

# Load data
data_path = "/Users/saadismail/Downloads/aclImdb"
train_texts, train_labels, test_texts, test_labels = load_imdb_data(data_path)

# Preprocess
preprocessor = TextPreprocessor()
train_clean = [" ".join(preprocessor.preprocess(text)) for text in train_texts]
test_clean = [" ".join(preprocessor.preprocess(text)) for text in test_texts]

# Tokenize
tokenizer = TextTokenizer(max_len=200)
tokenizer.fit(train_clean)
train_seq = tokenizer.texts_to_padded_sequences(train_clean)
test_seq = tokenizer.texts_to_padded_sequences(test_clean)

# Build + Train
model = build_model(vocab_size=10000, input_length=200)
train_labels = np.array(train_labels)
test_labels = np.array(test_labels)
model.fit(train_seq, train_labels, epochs=5, validation_data=(test_seq, test_labels), batch_size=512)

model.save("sentiment_model.h5")

def predict(text, tokenizer, preprocessor, model):
    cleaned = preprocessor.preprocess(text)
    joined = ' '.join(cleaned)
    padded = tokenizer.texts_to_padded_sequences([joined])
    prediction = model.predict(padded)[0][0]

    label = "Positive" if prediction >= 0.5 else "Negative"
    print(f"Review: {text}")
    print(f"Predicted Sentiment: {label} ({prediction:.4f})\n")


sentiment = input("Enter a Sentiment to Predict: ")

predict(sentiment, tokenizer, preprocessor, model)