import os

def load_imdb_data(data_dir):
    def load_from_folder(folder):
        texts, labels = [], []
        for label_type in ['pos', 'neg']:
            path = os.path.join(folder, label_type)
            label = 1 if label_type == 'pos' else 0
            for fname in os.listdir(path):
                if fname.endswith(".txt"):
                    with open(os.path.join(path, fname), encoding="utf-8") as f:
                        texts.append(f.read())
                        labels.append(label)
        return texts, labels

    train_dir = os.path.join(data_dir, "train")
    test_dir = os.path.join(data_dir, "test")
    train_texts, train_labels = load_from_folder(train_dir)
    test_texts, test_labels = load_from_folder(test_dir)

    return train_texts, train_labels, test_texts, test_labels
