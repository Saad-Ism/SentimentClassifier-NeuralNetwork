from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer

class TextTokenizer:
    def __init__(self, num_words=10000, oov_token="<OOV>", max_len=100):
        self.tokenizer = Tokenizer(num_words=num_words, oov_token=oov_token)
        self.max_len = max_len

    def fit(self, texts):
        self.tokenizer.fit_on_texts(texts)

    def texts_to_padded_sequences(self, texts):
        sequences = self.tokenizer.texts_to_sequences(texts)
        padded = pad_sequences(sequences, maxlen=self.max_len, padding="post", truncating="post")
        return padded

    def get_word_index(self):
        return self.tokenizer.word_index
