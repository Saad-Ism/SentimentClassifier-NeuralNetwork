import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

# Explicitly tell NLTK where to look for data
nltk.data.path.append("/Users/saadismail/nltk_data")

class TextPreprocessor:
    def __init__(self):
        self.stopwords = set(stopwords.words("english"))
        self.stemmer = PorterStemmer()

    def preprocess(self, text):
        # Lowercase
        text = text.lower()
        # Remove punctuation
        text = re.sub(r"[^\w\s]", "", text)
        # Tokenize
        raw_tokens = text.split()
        # Remove stopwords and stem
        tokens = [
            self.stemmer.stem(word)
            for word in raw_tokens
            if word not in self.stopwords
        ]
        return tokens
